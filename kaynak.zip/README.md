# Ana Ekran (TV Launcher)

[CleanYourTV](https://github.com/Gathin23/cleanyourtv) (Gathin23, MIT lisansı) başlatıcısından türetilmiş, sadeleştirilmiş Android TV ana ekranı.
Lisans metni `LICENSE` dosyasındadır; telif notu korunmalıdır.

- Ayarlar tuşu: Gizlilik ve Özelleştirme
- Gizlilik: şifre, ayarları şifrele, gizleme, uygulama kilidi
- Özelleştirme: satırdaki uygulama sayısı, duvar kağıdı, dock opaklığı, saat, animasyonlar

APK'yı GitHub'da Actions sekmesinden derleyin (APK derle iş akışı).
