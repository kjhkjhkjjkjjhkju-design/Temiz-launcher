# Ana Ekran (TV Launcher)

[CleanYourTV](https://github.com/Gathin23/cleanyourtv) (Gathin23, MIT lisansı) başlatıcısından türetilmiş, sadeleştirilmiş Android TV ana ekranı.
Lisans metni `LICENSE` dosyasındadır; telif notu korunmalıdır.
