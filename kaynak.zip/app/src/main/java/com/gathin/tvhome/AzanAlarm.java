package com.gathin.tvhome;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** One alarm, always for the next ezan; set again after it rings, when Home starts and when the TV boots. */
final class AzanAlarm {
    static final String ACTION = "com.gathin.tvhome.AZAN";

    private AzanAlarm() {
    }

    private static PendingIntent pending(Context c, int index) {
        Intent i = new Intent(c, AzanReceiver.class).setAction(ACTION).putExtra("idx", index);
        return PendingIntent.getBroadcast(c, 7, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Sets the alarm for the next ezan, or cancels it when ezan is off or the times are missing. */
    static void schedule(Context context) {
        Context c = context.getApplicationContext();
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am == null) return;
        long[] next = Namaz.azanOn(c) ? Namaz.next(c, true) : null;
        if (next == null) {
            am.cancel(pending(c, 0));
            return;
        }
        PendingIntent pi = pending(c, (int) next[1]);
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next[0], pi);
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next[0], pi);
        }
    }
}
