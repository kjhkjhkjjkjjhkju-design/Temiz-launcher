package com.gathin.tvhome;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.function.IntConsumer;

/** Özelleştirme: tiles per row, rows under the dock, dock opacity, clock, animations and the wallpaper. */
public final class CustomizeActivity extends Activity {
    private static final int PICK_IMAGE = 7;
    private static final int W = 1280;
    private static final int H = 720;
    private static final int[] DOCK_OPACITIES = {100, 70, 50, 30};
    private static final String[] CLOCKS = {"system", "12", "24"};

    private SharedPreferences choices;
    private TextView[] wallpaperChoices;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        choices = getSharedPreferences(Config.SETTINGS_NAME, MODE_PRIVATE);
        Config cfg = Config.load(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFF101419);
        scroll.setFillViewport(true);
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(72), dp(38), dp(72), dp(38));
        TextView title = new TextView(this);
        title.setText(R.string.pv_customize);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(34);
        p.addView(title);
        scroll.addView(p, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);

        TextView[] cols = choiceRow(p, getString(R.string.cz_columns), new String[]{"4", "5", "6", "7"},
                clamp(cfg.columns - 4, 3), i -> save(e -> e.putInt("columns", 4 + i)));
        choiceRow(p, getString(R.string.cz_rows), new String[]{"0", "1", "2", "3"},
                clamp(cfg.rowsBelowDock, 3), i -> save(e -> e.putInt(Config.ROWS_BELOW_DOCK_KEY, i)));

        boolean hasPicture = pictureFile() != null && pictureFile().isFile();
        String choice = choices.getString(Config.WALLPAPER_CHOICE_KEY, null);
        int wpSel = hasPicture && !"none".equals(choice) ? 1 : 0;
        wallpaperChoices = choiceRow(p, getString(R.string.cz_wallpaper),
                new String[]{getString(R.string.cz_wp_dynamic), getString(R.string.cz_wp_device)}, wpSel, i -> {
                    if (i == 0) {
                        save(e -> e.putString(Config.WALLPAPER_CHOICE_KEY, "none"));
                    } else {
                        pickImage();
                    }
                });

        String[] opacityLabels = new String[DOCK_OPACITIES.length];
        int opSel = 0;
        for (int i = 0; i < DOCK_OPACITIES.length; i++) {
            opacityLabels[i] = "%" + DOCK_OPACITIES[i];
            if (cfg.dockOpacity == DOCK_OPACITIES[i]) opSel = i;
        }
        choiceRow(p, getString(R.string.cz_dock_opacity), opacityLabels, opSel,
                i -> save(e -> e.putInt(Config.DOCK_OPACITY_KEY, DOCK_OPACITIES[i])));

        int clockSel = 0;
        for (int i = 0; i < CLOCKS.length; i++) if (CLOCKS[i].equals(cfg.clockFormat)) clockSel = i;
        choiceRow(p, getString(R.string.cz_clock), new String[]{getString(R.string.cz_clock_system), "12", "24"},
                clockSel, i -> save(e -> e.putString(Config.CLOCK_FORMAT_KEY, CLOCKS[i])));

        choiceRow(p, getString(R.string.cz_animations), new String[]{getString(R.string.on), getString(R.string.off)},
                cfg.animations ? 0 : 1, i -> save(e -> e.putBoolean("animations", i == 0)));

        cols[clamp(cfg.columns - 4, 3)].requestFocus();
    }

    private interface Edit {
        void apply(SharedPreferences.Editor e);
    }

    /** Saves a choice and bumps the change count: Home rebuilds when it next resumes. */
    private void save(Edit edit) {
        SharedPreferences.Editor e = choices.edit();
        edit.apply(e);
        e.apply();
        Privacy.bump(this);
        setResult(RESULT_OK);
    }

    private TextView[] choiceRow(LinearLayout p, String label, String[] options, int selected, IntConsumer onPick) {
        TextView l = new TextView(this);
        l.setText(label);
        l.setTextColor(0xFFFFFFFF);
        l.setTextSize(20);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        llp.topMargin = dp(22);
        p.addView(l, llp);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = dp(10);
        p.addView(row, rlp);

        final TextView[] views = new TextView[options.length];
        for (int i = 0; i < options.length; i++) {
            final int index = i;
            TextView t = new TextView(this, null, 0, R.style.SettingsRow);
            t.setText(options[i]);
            t.setGravity(Gravity.CENTER);
            t.setSelected(i == selected);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), 1f);
            lp.setMarginEnd(dp(10));
            t.setLayoutParams(lp);
            t.setOnClickListener(v -> {
                for (int k = 0; k < views.length; k++) views[k].setSelected(k == index);
                onPick.accept(index);
            });
            views[i] = t;
            row.addView(t);
        }
        return views;
    }

    private static int clamp(int v, int max) {
        return Math.max(0, Math.min(v, max));
    }

    // ---- wallpaper from the device ---------------------------------------------------------------

    private File pictureFile() {
        File dir = Config.dir(this);
        return dir == null ? null : new File(dir, Config.WALLPAPER_NAME);
    }

    private void pickImage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*");
        try {
            startActivityForResult(i, PICK_IMAGE);
            return;
        } catch (ActivityNotFoundException | SecurityException ignored) {
        }
        try {
            startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("image/*"), PICK_IMAGE);
        } catch (ActivityNotFoundException | SecurityException e) {
            File f = pictureFile();
            Toast.makeText(this, getString(R.string.cz_wp_no_picker, f == null ? "" : f.getAbsolutePath()),
                    Toast.LENGTH_LONG).show();
            restoreSelection();
        }
    }

    /** The picker was cancelled or failed: show the choice that is really in force. */
    private void restoreSelection() {
        if (wallpaperChoices == null) return;
        File f = pictureFile();
        boolean picture = f != null && f.isFile() && !"none".equals(choices.getString(Config.WALLPAPER_CHOICE_KEY, null));
        for (int k = 0; k < wallpaperChoices.length; k++) wallpaperChoices[k].setSelected(k == (picture ? 1 : 0));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_IMAGE) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            restoreSelection();
            return;
        }
        final Uri uri = data.getData();
        final Context app = getApplicationContext();
        new Thread(() -> {
            boolean ok;
            try {
                ok = saveWallpaper(app, uri);
            } catch (Throwable t) {
                ok = false;
            }
            final boolean saved = ok;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (saved) {
                    save(e -> e.remove(Config.WALLPAPER_CHOICE_KEY));
                    Toast.makeText(this, R.string.cz_wp_saved, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, R.string.cz_wp_failed, Toast.LENGTH_LONG).show();
                }
                restoreSelection();
            });
        }).start();
    }

    /** Crops the picture to 16:9, scales it to 1280x720, darkens it a little so the tiles stay readable. */
    private static boolean saveWallpaper(Context ctx, Uri uri) throws IOException {
        File dir = Config.dir(ctx);
        if (dir == null) return false;
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = ctx.getContentResolver().openInputStream(uri)) {
            if (in == null) return false;
            BitmapFactory.decodeStream(in, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false;
        int sample = 1;
        while (bounds.outWidth / (sample * 2) >= W && bounds.outHeight / (sample * 2) >= H) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        Bitmap src;
        try (InputStream in = ctx.getContentResolver().openInputStream(uri)) {
            if (in == null) return false;
            src = BitmapFactory.decodeStream(in, null, opts);
        }
        if (src == null) return false;
        Bitmap out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        float scale = Math.max((float) W / src.getWidth(), (float) H / src.getHeight());
        int sw = Math.min(src.getWidth(), Math.round(W / scale));
        int sh = Math.min(src.getHeight(), Math.round(H / scale));
        int sx = (src.getWidth() - sw) / 2;
        int sy = (src.getHeight() - sh) / 2;
        Canvas canvas = new Canvas(out);
        canvas.drawBitmap(src, new Rect(sx, sy, sx + sw, sy + sh), new Rect(0, 0, W, H),
                new Paint(Paint.FILTER_BITMAP_FLAG));
        canvas.drawColor(Color.argb(96, 0, 0, 0));
        src.recycle();
        File tmp = new File(dir, "wallpaper.tmp");
        try (FileOutputStream fo = new FileOutputStream(tmp)) {
            out.compress(Bitmap.CompressFormat.JPEG, 88, fo);
        } finally {
            out.recycle();
        }
        File dest = new File(dir, Config.WALLPAPER_NAME);
        if (dest.exists() && !dest.delete()) return false;
        return tmp.renameTo(dest);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
