package com.gathin.tvhome;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.io.File;

/** Shows the chosen wallpaper picture while Home is visible; nothing runs in the background. */
final class WallpaperPlayer {
    private final FrameLayout root;
    private final ImageView image;
    private final int backgroundColor;
    private final File file;
    private final int width;
    private final int height;
    /** config wallpaper_true_color: ARGB_8888 instead of RGB_565. */
    private final Bitmap.Config bitmapConfig;
    /** The picture on screen. */
    private Bitmap current;
    private boolean active;
    private boolean closed;

    WallpaperPlayer(Context context, FrameLayout root, Config config) {
        this.root = root;
        backgroundColor = config.backgroundColor;
        file = config.wallpaperEnabled && !config.wallpapers.isEmpty() ? config.wallpapers.get(0) : null;
        bitmapConfig = config.wallpaperTrueColor ? Bitmap.Config.ARGB_8888 : Bitmap.Config.RGB_565;
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        width = metrics.widthPixels;
        height = metrics.heightPixels;
        image = new ImageView(context);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        if (file != null) {
            root.addView(image, 0, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            // Decoded right here so Home's first frame already has it instead of the picture popping in later.
            load();
        }
    }

    void start() {
        active = true;
        update();
    }

    void stop() {
        active = false;
    }

    /** Brings the picture back after releaseForMemoryPressure. */
    void update() {
        if (active && !closed && file != null && current == null) load();
    }

    /** Drops the wallpaper texture when Home is hidden and Android asks the process to free memory. */
    void releaseForMemoryPressure() {
        if (current == null) return;
        image.setImageDrawable(null);
        // The renderer may still have a queued frame that references this hardware bitmap. Drop our reference and
        // let Android reclaim its native buffer after rendering releases it instead of recycling it mid-frame.
        current = null;
        root.setBackgroundColor(backgroundColor);
    }

    void close() {
        active = false;
        closed = true;
    }

    private void load() {
        Bitmap bitmap = decode(file);
        if (bitmap == null) return;
        current = bitmap;
        // The picture covers the whole screen: the root's plain colour under it is overdraw.
        root.setBackground(null);
        image.setImageBitmap(bitmap);
    }

    private Bitmap decode(File picture) {
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(picture.getPath(), options);
            int w = options.outWidth, h = options.outHeight;
            if (w <= 0 || h <= 0) return null;
            int sample = WallpaperSize.sampleSize(w, h, width, height);
            if (!WallpaperSize.accepted(w / sample, h / sample)) return null;
            options.inJustDecodeBounds = false;
            options.inSampleSize = sample;
            int[] scale = WallpaperSize.coverScale(w / sample, h / sample, width, height);
            if (scale != null) {
                options.inScaled = true;
                options.inDensity = scale[0];
                options.inTargetDensity = scale[1];
            }
            options.inPreferredConfig = bitmapConfig;
            Bitmap decoded = BitmapFactory.decodeFile(picture.getPath(), options);
            if (decoded == null) return null;
            // One copy in GPU memory instead of a software bitmap plus its texture.
            Bitmap gpu = decoded.copy(Bitmap.Config.HARDWARE, false);
            if (gpu == null) return decoded;
            decoded.recycle();
            return gpu;
        } catch (Exception | OutOfMemoryError failure) {
            return null;
        }
    }
}
