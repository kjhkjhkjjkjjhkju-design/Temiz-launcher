package com.gathin.tvhome;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * The ezan card: a small dark card at the top right, over whatever app is in front. It slides in, stays five
 * seconds, slides out and is removed. It exists only for those seconds; nothing runs before or after.
 */
final class AzanCard {
    private static final long SHOW_MS = 5000;
    private static final long IN_MS = 380;
    private static final long OUT_MS = 320;

    /** Main thread only. */
    private static View current;
    private static WindowManager currentWindows;
    private static Runnable currentDone;

    private AzanCard() {
    }

    static boolean available(Context c) {
        return Settings.canDrawOverlays(c);
    }

    /** The card when "show over other apps" is allowed, otherwise the system notification. done may be null. */
    static void announce(Context context, int index, String time, Runnable done) {
        Context app = context.getApplicationContext();
        if (!available(app) || !show(app, index, time, done)) {
            AzanNotice.show(app, index, time);
            if (done != null) done.run();
        }
    }

    private static boolean show(Context c, int index, String time, Runnable done) {
        try {
            dismissNow();
            final WindowManager wm = c.getSystemService(WindowManager.class);
            final float d = c.getResources().getDisplayMetrics().density;
            final int width = Math.round(300 * d);
            final int margin = Math.round(28 * d);

            LinearLayout card = new LinearLayout(c);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            int pad = Math.round(16 * d);
            card.setPadding(pad, pad, pad, pad);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xE61E1F20);            // #1E1F20 at 90%
            bg.setCornerRadius(20 * d);
            card.setBackground(bg);

            int circle = Math.round(44 * d);
            ImageView icon = new ImageView(c);
            GradientDrawable disc = new GradientDrawable();
            disc.setShape(GradientDrawable.OVAL);
            disc.setColor(0xFF3C4043);
            icon.setBackground(disc);
            icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            int inner = Math.round(10 * d);
            icon.setPadding(inner, inner, inner, inner);
            icon.setImageResource(R.drawable.ic_mosque);
            card.addView(icon, new LinearLayout.LayoutParams(circle, circle));

            LinearLayout texts = new LinearLayout(c);
            texts.setOrientation(LinearLayout.VERTICAL);
            TextView title = new TextView(c);
            title.setText(Namaz.NAMES[index] + " Vakti");
            title.setTextColor(0xFFFFFFFF);
            title.setTextSize(17);
            title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            title.setSingleLine(true);
            texts.addView(title);
            TextView clock = new TextView(c);
            clock.setText(time);
            clock.setTextColor(0xFFBDC1C6);
            clock.setTextSize(14);
            clock.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
            clock.setSingleLine(true);
            texts.addView(clock);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            tlp.setMarginStart(Math.round(14 * d));
            card.addView(texts, tlp);

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.END;
            lp.x = margin;
            lp.y = margin;
            lp.windowAnimations = 0;
            card.setTranslationX(width + margin);
            card.setAlpha(0f);
            wm.addView(card, lp);
            current = card;
            currentWindows = wm;
            currentDone = done;

            final Handler handler = new Handler(Looper.getMainLooper());
            card.animate().translationX(0f).alpha(1f).setDuration(IN_MS)
                    .setInterpolator(new DecelerateInterpolator(1.6f))
                    .withEndAction(() -> handler.postDelayed(() -> card.animate()
                            .translationX(width + margin).alpha(0f).setDuration(OUT_MS)
                            .setInterpolator(new AccelerateInterpolator(1.4f))
                            .withEndAction(() -> remove(card, wm)).start(), SHOW_MS))
                    .start();
            return true;
        } catch (Exception e) {
            dismissNow();
            return false;
        }
    }

    private static void dismissNow() {
        if (current != null) remove(current, currentWindows);
    }

    /** Takes the card off the screen and lets go of everything it held. */
    private static void remove(View card, WindowManager wm) {
        try {
            wm.removeView(card);
        } catch (Exception ignored) {
        }
        if (current == card) {
            Runnable done = currentDone;
            current = null;
            currentWindows = null;
            currentDone = null;
            if (done != null) done.run();
        }
    }
}
