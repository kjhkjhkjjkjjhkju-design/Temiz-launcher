package com.gathin.tvhome;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.chrono.HijrahDate;
import java.time.temporal.ChronoField;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Prayer times for a Turkish province (Diyanet method, from the free AlAdhan service, no key). Only the next ten
 * days are kept on disk, and the network is touched only when those days are missing, from a background thread
 * that starts when Home does. Nothing here runs on a timer.
 */
final class Namaz {
    interface Done {
        void run(boolean ok);
    }

    static final String[] NAMES = {"İmsak", "Güneş", "Öğle", "İkindi", "Akşam", "Yatsı"};
    /** Times that get an ezan: everything except Güneş (sunrise). */
    static final int SUNRISE = 1;
    static final String[] CITIES = {
            "Adana", "Adıyaman", "Afyonkarahisar", "Ağrı", "Aksaray", "Amasya", "Ankara", "Antalya", "Ardahan",
            "Artvin", "Aydın", "Balıkesir", "Bartın", "Batman", "Bayburt", "Bilecik", "Bingöl", "Bitlis", "Bolu",
            "Burdur", "Bursa", "Çanakkale", "Çankırı", "Çorum", "Denizli", "Diyarbakır", "Düzce", "Edirne",
            "Elazığ", "Erzincan", "Erzurum", "Eskişehir", "Gaziantep", "Giresun", "Gümüşhane", "Hakkâri", "Hatay",
            "Iğdır", "Isparta", "İstanbul", "İzmir", "Kahramanmaraş", "Karabük", "Karaman", "Kars", "Kastamonu",
            "Kayseri", "Kilis", "Kırıkkale", "Kırklareli", "Kırşehir", "Kocaeli", "Konya", "Kütahya", "Malatya",
            "Manisa", "Mardin", "Mersin", "Muğla", "Muş", "Nevşehir", "Niğde", "Ordu", "Osmaniye", "Rize",
            "Sakarya", "Samsun", "Şanlıurfa", "Siirt", "Sinop", "Sivas", "Şırnak", "Tekirdağ", "Tokat",
            "Trabzon", "Tunceli", "Uşak", "Van", "Yalova", "Yozgat", "Zonguldak"};
    private static final String[] HIJRI = {"Muharrem", "Safer", "Rebiülevvel", "Rebiülahir", "Cemaziyelevvel",
            "Cemaziyelahir", "Recep", "Şaban", "Ramazan", "Şevval", "Zilkade", "Zilhicce"};
    private static final int GOLD = Color.rgb(230, 195, 106);
    private static final String PREFS = "ezan";
    private static final String FILE = "namaz.json";
    private static final long RETRY_MS = 30 * 60 * 1000L;

    private static final Map<String, String> days = new HashMap<>();
    private static boolean loaded;
    private static volatile boolean busy;
    private static volatile long lastFail;

    private Namaz() {
    }

    // ---- settings ----------------------------------------------------------------------------------

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean timesOn(Context c) {
        return prefs(c).getBoolean("times_on", false);
    }

    static void setTimesOn(Context c, boolean on) {
        prefs(c).edit().putBoolean("times_on", on).apply();
    }

    static boolean azanOn(Context c) {
        return prefs(c).getBoolean("azan_on", false);
    }

    static void setAzanOn(Context c, boolean on) {
        prefs(c).edit().putBoolean("azan_on", on).apply();
    }

    /** True when either feature needs the times. */
    static boolean needed(Context c) {
        return timesOn(c) || azanOn(c);
    }

    static int city(Context c) {
        int i = prefs(c).getInt("city", 39);   // İstanbul
        return i >= 0 && i < CITIES.length ? i : 39;
    }

    static void setCity(Context c, int index) {
        prefs(c).edit().putInt("city", index).apply();
        synchronized (Namaz.class) {
            days.clear();
            loaded = true;
        }
        new File(c.getFilesDir(), FILE).delete();
        lastFail = 0;
    }

    // ---- data --------------------------------------------------------------------------------------

    private static String apiName(int index) {
        String s = CITIES[index];
        String from = "çğıöşüÇĞİÖŞÜâÂ";
        String to = "cgiosuCGIOSUaA";
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            int at = from.indexOf(ch);
            sb.append(at >= 0 ? to.charAt(at) : ch);
        }
        return sb.toString();
    }

    private static String readAll(InputStream in) throws IOException {
        try (InputStream is = in) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > 2_000_000) throw new IOException("too big");
            }
            return out.toString("UTF-8");
        }
    }

    private static synchronized void load(Context c) {
        if (loaded) return;
        loaded = true;
        days.clear();
        File f = new File(c.getFilesDir(), FILE);
        if (!f.isFile()) return;
        try {
            JSONObject o = new JSONObject(readAll(new FileInputStream(f)));
            if (o.optInt("city", -1) != city(c)) return;
            JSONObject d = o.getJSONObject("days");
            Iterator<String> it = d.keys();
            while (it.hasNext()) {
                String k = it.next();
                days.put(k, d.getString(k));
            }
        } catch (Exception ignored) {
        }
    }

    private static synchronized void save(Context c) {
        try {
            JSONObject o = new JSONObject();
            o.put("city", city(c));
            JSONObject d = new JSONObject();
            String oldest = LocalDate.now().minusDays(2).toString();
            for (Map.Entry<String, String> e : days.entrySet()) {
                if (e.getKey().compareTo(oldest) >= 0) d.put(e.getKey(), e.getValue());
            }
            o.put("days", d);
            try (FileOutputStream out = new FileOutputStream(new File(c.getFilesDir(), FILE))) {
                out.write(o.toString().getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) {
        }
    }

    /** The six times of a day as "HH:mm", or null when that day is not on disk. */
    static synchronized String[] day(Context c, LocalDate d) {
        load(c);
        String v = days.get(d.toString());
        if (v == null) return null;
        String[] t = v.split(",");
        return t.length == 6 ? t : null;
    }

    static long millis(String hhmm, LocalDate d) {
        return LocalDateTime.of(d, LocalTime.parse(hhmm)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    /** Fetches what is missing, off the main thread; done (may be null) runs on the main thread. */
    static void ensure(Context context, Done done) {
        final Context app = context.getApplicationContext();
        if (!needed(app)) return;
        LocalDate today = LocalDate.now();
        final boolean haveToday = day(app, today) != null;
        final LocalDate ahead = today.plusDays(10);
        final boolean haveAhead = day(app, ahead) != null;
        if (haveToday && haveAhead) {
            if (done != null) done.run(true);
            return;
        }
        if (busy || System.currentTimeMillis() - lastFail < RETRY_MS) return;
        busy = true;
        new Thread(() -> {
            boolean ok = true;
            try {
                if (!haveToday) fetchMonth(app, today.getYear(), today.getMonthValue());
                if (day(app, ahead) == null) fetchMonth(app, ahead.getYear(), ahead.getMonthValue());
                save(app);
            } catch (Exception e) {
                ok = false;
                lastFail = System.currentTimeMillis();
            }
            busy = false;
            final boolean result = ok;
            if (done != null) new Handler(Looper.getMainLooper()).post(() -> done.run(result));
        }, "namaz").start();
    }

    private static void fetchMonth(Context c, int year, int month) throws Exception {
        load(c);
        String url = "https://api.aladhan.com/v1/calendarByCity/" + year + "/" + month + "?city="
                + URLEncoder.encode(apiName(city(c)), "UTF-8") + "&country=Turkey&method=13";
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(15000);
        try {
            if (conn.getResponseCode() != 200) throw new IOException("http " + conn.getResponseCode());
            JSONArray data = new JSONObject(readAll(conn.getInputStream())).getJSONArray("data");
            String[] keys = {"Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"};
            synchronized (Namaz.class) {
                for (int i = 0; i < data.length(); i++) {
                    JSONObject o = data.getJSONObject(i);
                    String[] g = o.getJSONObject("date").getJSONObject("gregorian").getString("date").split("-");
                    JSONObject t = o.getJSONObject("timings");
                    StringBuilder sb = new StringBuilder();
                    for (int k = 0; k < keys.length; k++) {
                        if (k > 0) sb.append(',');
                        sb.append(t.getString(keys[k]).substring(0, 5));
                    }
                    days.put(g[2] + "-" + g[1] + "-" + g[0], sb.toString());
                }
            }
        } finally {
            conn.disconnect();
        }
    }

    // ---- what to show and when to ring ---------------------------------------------------------------

    /** The next time after now: {millis, index}. azanOnly skips Güneş. Null when no data. */
    static long[] next(Context c, boolean azanOnly) {
        LocalDate today = LocalDate.now();
        long now = System.currentTimeMillis();
        for (int off = 0; off < 2; off++) {
            LocalDate d = today.plusDays(off);
            String[] t = day(c, d);
            if (t == null) continue;
            for (int i = 0; i < 6; i++) {
                if (azanOnly && i == SUNRISE) continue;
                long m = millis(t[i], d);
                if (m > now) return new long[]{m, i};
            }
        }
        return null;
    }

    static String hijri(LocalDate d) {
        try {
            HijrahDate h = HijrahDate.from(d);
            return h.get(ChronoField.DAY_OF_MONTH) + " " + HIJRI[h.get(ChronoField.MONTH_OF_YEAR) - 1] + " "
                    + h.get(ChronoField.YEAR);
        } catch (Exception e) {
            return "";
        }
    }

    private static String remaining(long millis) {
        long m = Math.max(0, (millis - System.currentTimeMillis()) / 60000);
        return m >= 60 ? (m / 60) + " sa " + (m % 60) + " dk" : m + " dk";
    }

    /** The two lines under the clock, or null when today's times are not on disk yet. */
    static CharSequence row(Context c) {
        LocalDate today = LocalDate.now();
        String[] t = day(c, today);
        if (t == null) return null;
        long[] n = next(c, false);
        String first = hijri(today);
        int highlight = -1;
        if (n != null) {
            highlight = (int) n[1];
            first += "  ·  " + NAMES[(int) n[1]] + " " + new java.text.SimpleDateFormat("HH:mm",
                    java.util.Locale.US).format(new java.util.Date(n[0])) + " (" + remaining(n[0]) + ")";
        }
        SpannableStringBuilder sb = new SpannableStringBuilder(first).append('\n');
        boolean nextIsToday = n != null && LocalDate.now().equals(new java.util.Date(n[0]).toInstant()
                .atZone(ZoneId.systemDefault()).toLocalDate());
        for (int i = 0; i < 6; i++) {
            int start = sb.length();
            sb.append(NAMES[i]).append(' ').append(t[i]);
            if (nextIsToday && i == highlight) {
                sb.setSpan(new ForegroundColorSpan(GOLD), start, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            if (i < 5) sb.append("   ");
        }
        return sb;
    }
}
