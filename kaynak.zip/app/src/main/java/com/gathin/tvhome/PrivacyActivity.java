package com.gathin.tvhome;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * Gizlilik: PIN, "encrypt settings", and Gizleme (hide and lock every app). Locks itself behind the PIN
 * whenever one is set, every time it is opened.
 */
public final class PrivacyActivity extends Activity {
    private ScrollView scroll;
    private boolean unlocked;
    private boolean inApps;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFF101419);
        scroll.setFillViewport(true);
        setContentView(scroll);
        showMain(1);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (unlocked) return;
        if (!Privacy.hasPin(this)) {
            unlock();
            return;
        }
        scroll.setVisibility(View.INVISIBLE);
        PinDialog.verify(this, this::unlock, this::finish);
    }

    @Override
    protected void onStop() {
        super.onStop();
        unlocked = false;
    }

    private void unlock() {
        unlocked = true;
        scroll.setVisibility(View.VISIBLE);
        View first = ((ViewGroup) scroll.getChildAt(0)).getChildAt(1);
        if (first != null) first.requestFocus();
    }

    @Override
    public void onBackPressed() {
        if (inApps) {
            showMain(3);
            return;
        }
        super.onBackPressed();
    }

    // ---- pages -----------------------------------------------------------------------------------

    private LinearLayout page(String heading) {
        scroll.removeAllViews();
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(72), dp(38), dp(72), dp(38));
        TextView t = new TextView(this);
        t.setText(heading);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(34);
        p.addView(t);
        scroll.addView(p, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        return p;
    }

    private TextView row(String text, View.OnClickListener l) {
        TextView t = new TextView(this, null, 0, R.style.SettingsRow);
        t.setText(text);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        lp.topMargin = dp(14);
        t.setLayoutParams(lp);
        return t;
    }

    private String onOff(boolean on) {
        return getString(on ? R.string.on : R.string.off);
    }

    private void showMain(int focusIndex) {
        inApps = false;
        LinearLayout p = page(getString(R.string.pv_privacy));
        boolean pin = Privacy.hasPin(this);
        p.addView(row(getString(R.string.pv_password) + ": "
                + getString(pin ? R.string.pv_password_set : R.string.pv_password_not_set), v -> passwordClicked()));
        TextView enc = row(getString(R.string.pv_encrypt_settings, onOff(Privacy.encryptSettings(this))), v -> {
            if (!Privacy.hasPin(this)) {
                Toast.makeText(this, R.string.pv_need_password, Toast.LENGTH_SHORT).show();
                return;
            }
            Privacy.setEncryptSettings(this, !Privacy.encryptSettings(this));
            showMain(2);
        });
        if (!pin) enc.setAlpha(0.5f);
        p.addView(enc);
        p.addView(row(getString(R.string.pv_hiding), v -> showApps()));
        View target = p.getChildAt(Math.min(focusIndex, p.getChildCount() - 1));
        if (target != null) target.requestFocus();
    }

    private void passwordClicked() {
        if (!Privacy.hasPin(this)) {
            newPin();
            return;
        }
        String[] items = {getString(R.string.pv_change), getString(R.string.pv_remove)};
        new AlertDialog.Builder(this)
                .setTitle(R.string.pv_password)
                .setItems(items, (dialog, which) -> {
                    if (which == 0) {
                        newPin();
                    } else {
                        Privacy.clearPin(this);
                        Privacy.bump(this);
                        showMain(1);
                    }
                })
                .setNegativeButton(R.string.pv_cancel, null)
                .show();
    }

    private void newPin() {
        PinDialog.create(this, pin -> {
            Privacy.setPin(this, pin);
            Privacy.bump(this);
            showMain(1);
        }, () -> showMain(1));
    }

    private void showApps() {
        inApps = true;
        LinearLayout p = page(getString(R.string.pv_hiding));
        PackageManager pm = getPackageManager();
        List<String[]> apps = new ArrayList<>();
        Intent tv = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        Intent phone = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for (Intent query : new Intent[]{tv, phone}) {
            for (ResolveInfo r : pm.queryIntentActivities(query, 0)) {
                String pkg = r.activityInfo.packageName;
                if (pkg.equals(getPackageName())) continue;
                boolean seen = false;
                for (String[] a : apps) seen |= a[1].equals(pkg);
                if (!seen) apps.add(new String[]{r.loadLabel(pm).toString(), pkg});
            }
        }
        Collections.sort(apps, (a, b) -> a[0].compareToIgnoreCase(b[0]));
        Set<String> hidden = Privacy.hidden(this);
        for (String[] app : apps) addAppRow(p, app[0], app[1], hidden.contains(app[1]));
        View first = p.getChildCount() > 1 ? ((ViewGroup) p.getChildAt(1)).getChildAt(1) : null;
        if (first != null) first.requestFocus();
    }

    private void addAppRow(LinearLayout p, String label, String pkg, boolean hidden) {
        LinearLayout line = new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        llp.topMargin = dp(14);
        line.setLayoutParams(llp);

        TextView name = new TextView(this);
        name.setText(label);
        name.setTextColor(0xFFFFFFFF);
        name.setTextSize(18);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        line.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView hide = button(getString(R.string.pv_hide_state, onOff(hidden)), hidden);
        hide.setOnClickListener(v -> {
            boolean now = !Privacy.hidden(this).contains(pkg);
            Privacy.setHidden(this, pkg, now);
            Privacy.bump(this);
            hide.setText(getString(R.string.pv_hide_state, onOff(now)));
            hide.setSelected(now);
        });
        line.addView(hide);

        TextView lock = button(getString(R.string.pv_lock_state, onOff(Privacy.isLocked(this, pkg))),
                Privacy.isLocked(this, pkg));
        lock.setOnClickListener(v -> {
            if (!Privacy.hasPin(this)) {
                Toast.makeText(this, R.string.pv_need_password, Toast.LENGTH_SHORT).show();
                return;
            }
            boolean now = !Privacy.isLocked(this, pkg);
            Privacy.setLocked(this, pkg, now);
            lock.setText(getString(R.string.pv_lock_state, onOff(now)));
            lock.setSelected(now);
        });
        line.addView(lock);
        p.addView(line);
    }

    private TextView button(String text, boolean selected) {
        TextView t = new TextView(this, null, 0, R.style.SettingsRow);
        t.setText(text);
        t.setGravity(Gravity.CENTER);
        t.setSelected(selected);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(190), ViewGroup.LayoutParams.MATCH_PARENT);
        lp.setMarginStart(dp(10));
        t.setLayoutParams(lp);
        return t;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
