package com.gathin.tvhome;

import android.app.Activity;
import android.app.Dialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** A modern PIN pad that works with a remote: arrows move, OK presses, number keys type, Back cancels. */
final class PinDialog {
    static final int LEN = 4;

    interface Result {
        void ok(String pin);
    }

    private final Activity act;
    private final Dialog dialog;
    private final TextView title;
    private final TextView dots;
    private final StringBuilder entry = new StringBuilder();
    private Result result;
    private Runnable cancel;
    private boolean done;
    private View firstKey;

    /** Asks for the PIN and runs ok when it matches (at once when no PIN is set). cancel may be null. */
    static void verify(Activity a, Runnable ok, Runnable cancel) {
        if (!Privacy.hasPin(a)) {
            ok.run();
            return;
        }
        PinDialog d = new PinDialog(a, a.getString(R.string.pv_enter_password));
        d.cancel = cancel;
        d.result = pin -> {
            if (Privacy.verify(a, pin)) {
                d.finish();
                ok.run();
            } else {
                d.reject(a.getString(R.string.pv_wrong_password));
            }
        };
        d.show();
    }

    /** Collects a new PIN; the caller decides what to do with it. cancel may be null. */
    static void enter(Activity a, String heading, Result r, Runnable cancel) {
        PinDialog d = new PinDialog(a, heading);
        d.cancel = cancel;
        d.result = pin -> {
            d.finish();
            r.ok(pin);
        };
        d.show();
    }

    private PinDialog(Activity a, String heading) {
        act = a;
        dialog = new Dialog(a, android.R.style.Theme_Translucent_NoTitleBar);
        FrameLayout back = new FrameLayout(a);
        back.setBackgroundColor(0xCC000000);

        LinearLayout panel = new LinearLayout(a);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setPadding(dp(32), dp(26), dp(32), dp(26));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF1B2027);
        bg.setCornerRadius(dp(26));
        panel.setBackground(bg);

        title = new TextView(a);
        title.setText(heading);
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        panel.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        dots = new TextView(a);
        dots.setTextColor(Color.WHITE);
        dots.setTextSize(30);
        dots.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        dlp.topMargin = dp(10);
        dlp.bottomMargin = dp(10);
        panel.addView(dots, dlp);

        String[] labels = {"1", "2", "3", "4", "5", "6", "7", "8", "9",
                a.getString(R.string.pv_delete), "0", a.getString(R.string.pv_cancel)};
        for (int r = 0; r < 4; r++) {
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < 3; c++) {
                final String label = labels[r * 3 + c];
                TextView key = key(label);
                if (firstKey == null) firstKey = key;
                key.setOnClickListener(v -> {
                    if (label.equals(a.getString(R.string.pv_delete))) backspace();
                    else if (label.equals(a.getString(R.string.pv_cancel))) dialog.cancel();
                    else digit(label.charAt(0) - '0');
                });
                row.addView(key);
            }
            panel.addView(row);
        }

        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        back.addView(panel, plp);
        dialog.setContentView(back);
        dialog.setOnCancelListener(d -> {
            if (!done && cancel != null) cancel.run();
        });
        dialog.setOnKeyListener((d, code, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (code >= KeyEvent.KEYCODE_0 && code <= KeyEvent.KEYCODE_9) {
                digit(code - KeyEvent.KEYCODE_0);
                return true;
            }
            if (code == KeyEvent.KEYCODE_DEL) {
                backspace();
                return true;
            }
            return false;
        });
        render();
    }

    private TextView key(String label) {
        TextView t = new TextView(act);
        t.setText(label);
        t.setTextSize(22);
        t.setGravity(Gravity.CENTER);
        t.setFocusable(true);
        t.setFocusableInTouchMode(true);
        t.setClickable(true);
        t.setTextColor(new ColorStateList(
                new int[][]{{android.R.attr.state_focused}, {}},
                new int[]{Color.BLACK, Color.WHITE}));
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, shape(0xFFFFFFFF));
        sl.addState(new int[]{android.R.attr.state_pressed}, shape(0xFFCCCCCC));
        sl.addState(new int[]{}, shape(0xFF2A313A));
        t.setBackground(sl);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(84), dp(58));
        lp.setMargins(dp(6), dp(6), dp(6), dp(6));
        t.setLayoutParams(lp);
        return t;
    }

    private GradientDrawable shape(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(16));
        return g;
    }

    private void show() {
        dialog.show();
        if (firstKey != null) firstKey.requestFocus();
    }

    private void finish() {
        done = true;
        dialog.dismiss();
    }

    private void digit(int d) {
        if (entry.length() >= LEN) return;
        entry.append(d);
        render();
        if (entry.length() == LEN) {
            final String pin = entry.toString();
            dots.postDelayed(() -> {
                if (!done && result != null) result.ok(pin);
            }, 90);
        }
    }

    private void backspace() {
        if (entry.length() == 0) return;
        entry.setLength(entry.length() - 1);
        render();
    }

    private void reject(String message) {
        entry.setLength(0);
        title.setText(message);
        render();
        dots.animate().translationX(dp(14)).setDuration(60)
                .withEndAction(() -> dots.animate().translationX(0).setDuration(60).start()).start();
    }

    private void render() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < LEN; i++) {
            if (i > 0) sb.append(' ');
            sb.append(i < entry.length() ? '\u25CF' : '\u25CB');
        }
        dots.setText(sb);
    }

    private int dp(int v) {
        return Math.round(v * act.getResources().getDisplayMetrics().density);
    }
}
