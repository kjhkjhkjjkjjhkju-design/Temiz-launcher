package com.gathin.tvhome;

import android.app.Activity;
import android.app.Dialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Modern PIN pad that works with a remote: arrows move, OK presses, number keys type, Back cancels. */
final class PinDialog {
    static final int LEN = 4;

    interface Result {
        void ok(String pin);
    }

    private final Activity act;
    private final Dialog dialog;
    private final TextView title;
    private final LinearLayout dotRow;
    private final View[] dots = new View[LEN];
    private final StringBuilder entry = new StringBuilder();
    private Result result;
    private Runnable cancel;
    private boolean done;
    private View firstKey;

    /** Asks for the PIN and runs ok when it matches (at once when no PIN is set). cancel may be null. */
    static void verify(Activity a, Runnable ok, Runnable cancel) {
        if (!Privacy.hasPin(a)) {
            ok.run();
            return;
        }
        PinDialog d = new PinDialog(a, a.getString(R.string.pv_enter_password));
        d.cancel = cancel;
        d.result = pin -> {
            if (Privacy.verify(a, pin)) {
                d.finish();
                ok.run();
            } else {
                d.reject(a.getString(R.string.pv_wrong_password));
            }
        };
        d.show();
    }

    /** New PIN: typed twice inside one dialog, so the screen never closes and reopens in between. */
    static void create(Activity a, Result r, Runnable cancel) {
        PinDialog d = new PinDialog(a, a.getString(R.string.pv_set_password));
        d.cancel = cancel;
        final String[] first = {null};
        d.result = pin -> {
            if (first[0] == null) {
                first[0] = pin;
                d.next(a.getString(R.string.pv_repeat_password));
            } else if (first[0].equals(pin)) {
                d.finish();
                r.ok(pin);
            } else {
                first[0] = null;
                d.reject(a.getString(R.string.pv_mismatch));
            }
        };
        d.show();
    }

    private PinDialog(Activity a, String heading) {
        act = a;
        dialog = new Dialog(a, android.R.style.Theme_Translucent_NoTitleBar);
        FrameLayout back = new FrameLayout(a);
        back.setBackgroundColor(0xCC000000);

        LinearLayout panel = new LinearLayout(a);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setPadding(dp(26), dp(28), dp(26), dp(22));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF0161B22);
        bg.setCornerRadius(dp(30));
        bg.setStroke(dp(1), 0x33FFFFFF);
        panel.setBackground(bg);

        title = new TextView(a);
        title.setText(heading);
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        panel.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        dotRow = new LinearLayout(a);
        dotRow.setOrientation(LinearLayout.HORIZONTAL);
        dotRow.setGravity(Gravity.CENTER);
        for (int i = 0; i < LEN; i++) {
            View dot = new View(a);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(16), dp(16));
            dlp.setMargins(dp(9), 0, dp(9), 0);
            dotRow.addView(dot, dlp);
            dots[i] = dot;
        }
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = dp(18);
        rlp.bottomMargin = dp(16);
        panel.addView(dotRow, rlp);

        final String del = a.getString(R.string.pv_delete);
        final String cancelLabel = a.getString(R.string.pv_cancel);
        String[] labels = {"1", "2", "3", "4", "5", "6", "7", "8", "9", del, "0", cancelLabel};
        for (int r = 0; r < 4; r++) {
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < 3; c++) {
                final String label = labels[r * 3 + c];
                TextView key = key(label, label.length() == 1);
                if (firstKey == null) firstKey = key;
                key.setOnClickListener(v -> {
                    if (label.equals(del)) backspace();
                    else if (label.equals(cancelLabel)) dialog.cancel();
                    else digit(label.charAt(0) - '0');
                });
                row.addView(key);
            }
            panel.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        back.addView(panel, new FrameLayout.LayoutParams(dp(360), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));
        dialog.setContentView(back, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        dialog.setOnCancelListener(d -> {
            if (!done && cancel != null) cancel.run();
        });
        dialog.setOnKeyListener((d, code, ev) -> {
            if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
            if (code >= KeyEvent.KEYCODE_0 && code <= KeyEvent.KEYCODE_9) {
                digit(code - KeyEvent.KEYCODE_0);
                return true;
            }
            if (code == KeyEvent.KEYCODE_DEL) {
                backspace();
                return true;
            }
            return false;
        });
        render();
    }

    private TextView key(String label, boolean digit) {
        TextView t = new TextView(act);
        t.setText(label);
        t.setTextSize(digit ? 26 : 16);
        t.setGravity(Gravity.CENTER);
        t.setFocusable(true);
        t.setFocusableInTouchMode(true);
        t.setClickable(true);
        t.setTextColor(new ColorStateList(
                new int[][]{{android.R.attr.state_focused}, {}},
                new int[]{Color.BLACK, Color.WHITE}));
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, shape(0xFFFFFFFF));
        sl.addState(new int[]{android.R.attr.state_pressed}, shape(0xFFD0D5DB));
        sl.addState(new int[]{}, shape(digit ? 0xFF262E38 : 0xFF1E252D));
        t.setBackground(sl);
        t.setOnFocusChangeListener((v, focused) -> v.animate().scaleX(focused ? 1.06f : 1f)
                .scaleY(focused ? 1.06f : 1f).setDuration(120).start());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(62), 1f);
        lp.setMargins(dp(6), dp(6), dp(6), dp(6));
        t.setLayoutParams(lp);
        return t;
    }

    private GradientDrawable shape(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(31));
        return g;
    }

    private void show() {
        dialog.show();
        if (firstKey != null) firstKey.requestFocus();
    }

    private void finish() {
        done = true;
        dialog.dismiss();
    }

    private void next(String heading) {
        entry.setLength(0);
        title.setText(heading);
        render();
    }

    private void digit(int d) {
        if (entry.length() >= LEN) return;
        entry.append(d);
        render();
        if (entry.length() == LEN) {
            final String pin = entry.toString();
            dotRow.postDelayed(() -> {
                if (!done && result != null) result.ok(pin);
            }, 120);
        }
    }

    private void backspace() {
        if (entry.length() == 0) return;
        entry.setLength(entry.length() - 1);
        render();
    }

    private void reject(String message) {
        entry.setLength(0);
        title.setText(message);
        render();
        dotRow.animate().translationX(dp(14)).setDuration(60)
                .withEndAction(() -> dotRow.animate().translationX(0).setDuration(60).start()).start();
    }

    private void render() {
        for (int i = 0; i < LEN; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            if (i < entry.length()) {
                g.setColor(0xFFFFFFFF);
            } else {
                g.setColor(0x00000000);
                g.setStroke(dp(2), 0x88FFFFFF);
            }
            dots[i].setBackground(g);
        }
    }

    private int dp(int v) {
        return Math.round(v * act.getResources().getDisplayMetrics().density);
    }
}
