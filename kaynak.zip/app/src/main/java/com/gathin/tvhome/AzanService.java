package com.gathin.tvhome;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;

/**
 * Plays the ezan, with a band across the bottom of the screen over whatever app is in front. It lives only while
 * the ezan plays: any key stops it, and it ends by itself when the sound ends.
 */
public final class AzanService extends Service {
    static final String FILE = "azan.mp3";
    static final String FILE_FAJR = "azan-sabah.mp3";
    private static final String CHANNEL = "azan";

    private MediaPlayer player;
    private AudioManager audio;
    private AudioFocusRequest focus;
    private WindowManager windows;
    private View band;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        int index = intent != null ? intent.getIntExtra("idx", 2) : 2;
        if (index < 0 || index >= Namaz.NAMES.length) index = 2;
        String title = Namaz.NAMES[index] + " ezanı";
        startInForeground(title);
        release();
        showBand(title);
        play(index);
        return START_NOT_STICKY;
    }

    private void startInForeground(String title) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, getString(R.string.ez_title),
                    NotificationManager.IMPORTANCE_LOW));
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        Notification n = b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title).build();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(31, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(31, n);
            }
        } catch (Exception ignored) {
        }
    }

    private void play(int index) {
        File f = new File(getFilesDir(), index == 0 ? FILE_FAJR : FILE);
        if (!f.isFile()) f = new File(getFilesDir(), FILE);
        try {
            AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
            audio = getSystemService(AudioManager.class);
            focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(attrs).build();
            if (audio != null) audio.requestAudioFocus(focus);
            player = new MediaPlayer();
            player.setAudioAttributes(attrs);
            if (f.isFile()) {
                player.setDataSource(f.getAbsolutePath());
            } else {
                player.setDataSource(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
            }
            player.setOnCompletionListener(mp -> stopSelf());
            player.setOnErrorListener((mp, what, extra) -> {
                stopSelf();
                return true;
            });
            player.prepare();
            player.start();
        } catch (Exception e) {
            stopSelf();
        }
    }

    private void showBand(String title) {
        if (!Settings.canDrawOverlays(this)) return;
        try {
            windows = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            float d = getResources().getDisplayMetrics().density;
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER_HORIZONTAL);
            int pad = Math.round(18 * d);
            box.setPadding(pad * 2, pad, pad * 2, pad);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xE6101419);
            bg.setCornerRadii(new float[]{28 * d, 28 * d, 28 * d, 28 * d, 0, 0, 0, 0});
            box.setBackground(bg);
            TextView t = new TextView(this);
            t.setText(title);
            t.setTextColor(0xFFE6C36A);
            t.setTextSize(26);
            t.setGravity(Gravity.CENTER);
            box.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView hint = new TextView(this);
            hint.setText(R.string.ez_stop_hint);
            hint.setTextColor(0xB3FFFFFF);
            hint.setTextSize(14);
            hint.setGravity(Gravity.CENTER);
            box.addView(hint, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
            // Focusable on purpose: that is how a key press reaches us over another app.
            box.setFocusable(true);
            box.setFocusableInTouchMode(true);
            box.setOnKeyListener((v, code, event) -> {
                if (event.getAction() == KeyEvent.ACTION_UP) stopSelf();
                return true;
            });
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.BOTTOM;
            windows.addView(box, lp);
            band = box;
            box.requestFocus();
        } catch (Exception e) {
            band = null;
        }
    }

    private void release() {
        if (player != null) {
            try {
                player.release();
            } catch (Exception ignored) {
            }
            player = null;
        }
        if (band != null && windows != null) {
            try {
                windows.removeView(band);
            } catch (Exception ignored) {
            }
            band = null;
        }
        if (audio != null && focus != null) {
            audio.abandonAudioFocusRequest(focus);
            focus = null;
        }
    }

    @Override
    public void onDestroy() {
        release();
        super.onDestroy();
    }
}
