package com.gathin.tvhome;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Privacy state: the PIN (salted SHA-256, never stored in clear), the "encrypt settings" switch, and the
 * per-app hidden and locked sets. Everything lives in one small SharedPreferences file.
 */
final class Privacy {
    private static final String PREFS = "privacy";
    private static final String K_HASH = "pin_hash";
    private static final String K_SALT = "pin_salt";
    private static final String K_ENCRYPT = "encrypt_settings";
    private static final String K_HIDDEN = "hidden";
    private static final String K_LOCKED = "locked";

    private Privacy() {
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean hasPin(Context c) {
        return prefs(c).contains(K_HASH);
    }

    static void setPin(Context c, String pin) {
        byte[] salt = new byte[8];
        new SecureRandom().nextBytes(salt);
        String s = hex(salt);
        prefs(c).edit().putString(K_SALT, s).putString(K_HASH, hash(s, pin)).apply();
    }

    /** True when the PIN matches, or when no PIN is set. */
    static boolean verify(Context c, String pin) {
        SharedPreferences p = prefs(c);
        String h = p.getString(K_HASH, null);
        if (h == null) return true;
        return h.equals(hash(p.getString(K_SALT, ""), pin));
    }

    /** Removing the PIN also drops everything that depends on it. */
    static void clearPin(Context c) {
        prefs(c).edit().remove(K_HASH).remove(K_SALT).remove(K_ENCRYPT).remove(K_LOCKED).apply();
    }

    static boolean encryptSettings(Context c) {
        return hasPin(c) && prefs(c).getBoolean(K_ENCRYPT, false);
    }

    static void setEncryptSettings(Context c, boolean on) {
        prefs(c).edit().putBoolean(K_ENCRYPT, on).apply();
    }

    static Set<String> hidden(Context c) {
        return copy(prefs(c).getStringSet(K_HIDDEN, Collections.emptySet()));
    }

    static void setHidden(Context c, String pkg, boolean on) {
        toggle(c, K_HIDDEN, pkg, on);
    }

    static boolean isLocked(Context c, String pkg) {
        return hasPin(c) && copy(prefs(c).getStringSet(K_LOCKED, Collections.emptySet())).contains(pkg);
    }

    static void setLocked(Context c, String pkg, boolean on) {
        toggle(c, K_LOCKED, pkg, on);
    }

    /** Asks for the PIN first when "encrypt settings" is on; otherwise runs the action at once. */
    static void gate(Activity a, Runnable action) {
        if (encryptSettings(a)) PinDialog.verify(a, action, null);
        else action.run();
    }

    /** Home rebuilds on its next resume when this change count moves. */
    static void bump(Context c) {
        SharedPreferences s = c.getSharedPreferences(Config.SETTINGS_NAME, Context.MODE_PRIVATE);
        s.edit().putLong(Config.SETTINGS_REVISION_KEY, s.getLong(Config.SETTINGS_REVISION_KEY, 0) + 1).apply();
    }

    private static void toggle(Context c, String key, String pkg, boolean on) {
        Set<String> set = copy(prefs(c).getStringSet(key, Collections.emptySet()));
        if (on) set.add(pkg);
        else set.remove(pkg);
        prefs(c).edit().putStringSet(key, set).apply();
    }

    private static Set<String> copy(Set<String> in) {
        return in == null ? new HashSet<>() : new HashSet<>(in);
    }

    private static String hash(String salt, String pin) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return hex(md.digest((salt + ":" + pin).getBytes("UTF-8")));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }
}
