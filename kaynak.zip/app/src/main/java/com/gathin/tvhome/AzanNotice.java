package com.gathin.tvhome;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;

/** The ezan is a plain system notification: no sound, no service, and the system removes it after ten seconds. */
final class AzanNotice {
    private static final String CHANNEL = "azan";
    private static final int ID = 31;
    private static final long TIMEOUT_MS = 10_000;

    private AzanNotice() {
    }

    static boolean allowed(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        return nm != null && nm.areNotificationsEnabled();
    }

    /** "Öğle Ezanı" with the time (or any short text) under it. */
    static void show(Context context, int index, String text) {
        Context c = context.getApplicationContext();
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null || !nm.areNotificationsEnabled()) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL, c.getString(R.string.ez_title),
                NotificationManager.IMPORTANCE_HIGH);
        channel.setSound(null, null);
        channel.enableVibration(false);
        nm.createNotificationChannel(channel);
        Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_mosque)
                .setContentTitle(Namaz.NAMES[index] + " Ezanı")
                .setContentText(text)
                .setAutoCancel(true)
                .setTimeoutAfter(TIMEOUT_MS)
                .build();
        nm.notify(ID, n);
    }
}
