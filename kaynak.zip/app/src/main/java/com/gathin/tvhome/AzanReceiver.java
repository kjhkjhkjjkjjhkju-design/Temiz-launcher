package com.gathin.tvhome;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.time.LocalDate;

/** The alarm and the boot: posts the ezan notification when it is time, and always sets the next alarm. */
public final class AzanReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (AzanAlarm.ACTION.equals(intent.getAction()) && Namaz.azanOn(context)) {
            int index = intent.getIntExtra("idx", 0);
            if (index < 0 || index >= Namaz.NAMES.length) index = 0;
            String[] times = Namaz.day(context, LocalDate.now());
            AzanNotice.show(context, index, times != null ? times[index] : "");
        }
        AzanAlarm.schedule(context);
    }
}
