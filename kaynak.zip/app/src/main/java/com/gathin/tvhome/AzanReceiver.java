package com.gathin.tvhome;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** The alarm and the boot: starts the ezan when it is time, and always sets the next alarm. */
public final class AzanReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (AzanAlarm.ACTION.equals(action) && Namaz.azanOn(context)) {
            Intent service = new Intent(context, AzanService.class).putExtra("idx", intent.getIntExtra("idx", 0));
            try {
                context.startForegroundService(service);
            } catch (Exception ignored) {
            }
        }
        AzanAlarm.schedule(context);
    }
}
