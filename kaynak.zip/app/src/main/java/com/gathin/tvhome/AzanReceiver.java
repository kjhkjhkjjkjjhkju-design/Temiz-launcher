package com.gathin.tvhome;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;

import java.time.LocalDate;
import java.util.concurrent.atomic.AtomicBoolean;

/** The alarm and the boot: shows the ezan card when it is time, and always sets the next alarm first. */
public final class AzanReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        AzanAlarm.schedule(context);
        if (!AzanAlarm.ACTION.equals(intent.getAction()) || !Namaz.azanOn(context)) return;
        int index = intent.getIntExtra("idx", 0);
        if (index < 0 || index >= Namaz.NAMES.length) index = 0;
        String[] times = Namaz.day(context, LocalDate.now());
        String time = times != null ? times[index] : "";
        // Hold the broadcast open while the card is on screen so the process is not stopped under it.
        final PendingResult result = goAsync();
        final AtomicBoolean finished = new AtomicBoolean();
        final Runnable finish = () -> {
            if (finished.compareAndSet(false, true)) result.finish();
        };
        new Handler(Looper.getMainLooper()).postDelayed(finish, 15000);
        AzanCard.announce(context, index, time, finish);
    }
}
